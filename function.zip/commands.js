const program = require('commander');

program
  .option('--lambdaUpload', 'lambdaUpload')
  .option('--lambdaTest', 'lambdaTest')
  .option('--lambdaPermissionsSet', 'lambdaPermissionsSet')
  .option('--lambdaPermissionsView', 'lambdaPermissionsView');

program.parse(process.argv);

if (program.lambdaUpload){
  console.log('lambdaUpload');
}else if(program.lambdaTest){
  console.log('lambdaTest');
}else if(program.lambdaPermissionsSet){
  console.log('lambdaPermissionsSet');
  //console.log(`- ${program.pizzaType}`);
}else if(program.lambdaPermissionsView){
  console.log('lambdaPermissionsView');
  //console.log(`- ${program.pizzaType}`);
}else{
  console.log("Please pass a valid argument...");
}
